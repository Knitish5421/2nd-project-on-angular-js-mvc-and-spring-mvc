package com.prohance.mapper.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.prohance.confi.MyBatisUtil;
import com.prohance.exception.RecordNotFoundException;
import com.prohance.model.Employee;
@Service
public class EmployeeMapper {
	
	
	public List<Employee> getAllEmployees() {
		SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
		List<Employee> list = session.selectList("EmployeeMapper.getAllEmployees");
		session.commit();
		session.close();
	    return list; 
	}
	
	public void deletById(Long id)throws RecordNotFoundException
	{
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
	}
	

	public Integer deletById1(Long id)
	{
		SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
		Integer ids=session.delete("EmployeeMapper.deleteById", id);
		session.commit();
		session.close();
		return ids;
	}
	
	
	
	
public Employee getDataById(Long id) {
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Employee employee = session.selectOne("EmployeeMapper.getById",id );
	session.commit();
	session.close();
	return employee;
	
}
	
public Integer updateById(Employee employee)
{
	SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
	Integer i=session.update("EmployeeMapper.update",employee );
	session.commit();
	session.close();
	return i;
	
}

public void insertEmployee(Employee employee) throws RecordNotFoundException
{
SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
session.insert("EmployeeMapper.insert",employee );
session.commit();
session.close();
}

public Integer insert(Employee employee) 
{
SqlSession session= MyBatisUtil.getSqlSessionFactory().openSession();
Integer emp=session.insert("EmployeeMapper.insert",employee );
session.commit();
session.close();
return emp;
}

public List<Employee> getFnameLname( String firstname) {
	SqlSession session = MyBatisUtil.getSqlSessionFactory().openSession();
	 List<Employee> employeeList  = session.selectList("EmployeeMapper.getFirstLastName",firstname);
	session.commit();
	session.close();
    return employeeList; 
}



}
