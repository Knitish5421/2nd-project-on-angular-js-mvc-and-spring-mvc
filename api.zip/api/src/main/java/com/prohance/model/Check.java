package com.prohance.model;

public class Check {
private String condition;
public String getCondition() {
	return condition;
}

public void setCondition(String condition) {
	this.condition = condition;
}


}

