app.service('loginService',function($http){
	this.login = function (login) {
	    var response = $http({
	        method: "post",
	        url: "template/rest/login",
	        
	        data : angular.toJson(login),
			headers : {
				'Content-Type' : 'application/json'
			}
	    });
	    return response;
	}
})