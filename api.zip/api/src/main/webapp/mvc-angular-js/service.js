//var app = angular.module('myapp', ['angularUtils.directives.dirPagination']);
app.service('crudService',function($http){

this.getAll = function () {
    return $http.get("template/rest/employees");
};

this.updateEmp = function (employee) {
    var response = $http({
        method: "post",
        url: "template/rest/update",
        data : angular.toJson(employee),
		headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}
this.AddEmp = function (employee) {
    var response = $http({
        method: "post",
        url: "template/rest/employee",
        data : angular.toJson(employee),
		headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}

this.DeleteEmp = function (id) {
    var response = $http({
        method: "DELETE",
        url:'template/rest/employee/' + id,
        headers : {
			'Content-Type' : 'application/json'
		}
    });
    return response;
}

})