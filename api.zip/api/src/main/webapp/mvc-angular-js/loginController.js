app.controller("loginController", function ($scope,$window,$state, loginService){
	$scope.username='';
	$scope.password='';
    $scope.condition='';
	$scope.check="fail";
	
	  $scope.loginEmployee=function(){
		  var unpwd={
	  			   username:$scope.username,
	  			   password :$scope.password,
		  }
	  loginService.login(unpwd).then(function (response) {
		  $scope.condition=response.data;
		  
			 if(angular.equals($scope.condition.condition,$scope.check)){
				 
				 $scope.errorsms="username and password is worng";
			 }
			 else{
					$state.go('views');
				 
			 }
		});
		   
	  }
	
})
