app.controller("loginController", function ($scope,$window,$state){
	
	
})
	